#include <stdio.h>
#include "linkedList.h"
#include <stdlib.h>


Status InitList(LinkedList *L) 
{

    *L = (LinkedList)malloc(sizeof(LNode));
    if (*L == NULL) 
    {
        return ERROR;  // 内存分配失败
    }
    (*L)->next = NULL;
    return SUCCESS;
}


void DestroyList(LinkedList *L) 
{
    LinkedList temp;
    
    // 循环释放所有节点内存
    while (*L != NULL) 
    {
        temp = *L;  
        *L = (*L)->next;  
        free(temp); 
    }
}


Status InsertList(LNode *p, LNode *q) 
{
    if (p == NULL || q == NULL)
    {
        return ERROR;
    }
    
    // 将q节点插入p节点后面
    q->next = p->next;
    p->next = q;
    
    return SUCCESS;
}


Status DeleteList(LNode *p, ElemType *e) 
{
    if (p == NULL || p->next == NULL)
    {
        return ERROR;  // p为空或p是最后一个节点
    }
    LNode *q = p->next; 
    *e = q->data;  // 保存节点数据
    p->next = q->next; 
    free(q);
    return SUCCESS;
}