#include <stdio.h>
#include "linkedList.h"
#include <stdlib.h>


Status InitList(LinkedList *L) 
{

    *L = (LinkedList)malloc(sizeof(LNode));
    if (*L == NULL) 
    {
        return ERROR;  // 内存分配失败
    }
    (*L)->next = NULL;
    return SUCCESS;
}


void DestroyList(LinkedList *L) 
{
    LinkedList temp;
    
    // 循环释放所有节点内存
    while (*L != NULL) 
    {
        temp = *L;  
        *L = (*L)->next;  
        free(temp); 
    }
}


Status InsertList(LNode *p, LNode *q) 
{
    if (p == NULL || q == NULL)
    {
        return ERROR;
    }
    
    // 将q节点插入p节点后面
    q->next = p->next;
    p->next = q;
    
    return SUCCESS;
}


Status DeleteList(LNode *p, ElemType *e) 
{
    if (p == NULL || p->next == NULL)
    {
        return ERROR;  // p为空或p是最后一个节点
    }
    LNode *q = p->next; 
    *e = q->data;  // 保存节点数据
    p->next = q->next; 
    free(q);
    return SUCCESS;
}

void TraverseList(LinkedList L, void (*visit)(ElemType)) {
    LNode* current = L->next;
    while (current != NULL) {
        visit(current->data);
        current = current->next;
    }
    printf("NULL\n");
}

void printNode(ElemType e) {
    printf("%d -> ", e);
}

LNode* createNode(ElemType data) {
    LNode* newNode = (LNode*)malloc(sizeof(LNode));
    if (newNode == NULL) {
        printf("Memory allocation failed!\n");
        return NULL;
    }
    newNode->data = data;
    newNode->next = NULL;
    return newNode;
}

Status createListFromInput(LinkedList* L) {
    int n, data;
    printf("Enter the number of nodes to create: ");
    scanf("%d", &n);
    
    if (n < 0) {
        printf("Number of nodes cannot be negative!\n");
        return ERROR;
    }
    
    if (InitList(L) == ERROR) {
        printf("List initialization failed!\n");
        return ERROR;
    }
    
    LNode* current = *L;
    printf("Please enter %d integers:\n", n);
    for (int i = 0; i < n; i++) {
        scanf("%d", &data);
        LNode* newNode = createNode(data);
        if (newNode == NULL) {
            return ERROR;
        }
        InsertList(current, newNode);
        current = newNode;
    }
    return SUCCESS;
}

void printMenu() {
    printf("1. Create New List\n");
    printf("2. Print List\n");
    printf("0. Exit Program\n");
}

int main() {
    LinkedList L = NULL;
    int choice;
    ElemType midData;
    LNode* midNode;
    
    while (1) {
        printMenu();
        scanf("%d", &choice);
        
        switch (choice) {
            case 0://退出程序
                if (L != NULL) {
                    DestroyList(&L);
                }
                printf("Program terminated.\n");
                return 0;
                
            case 1://创建新链表
                if (L != NULL) 
                {
                    DestroyList(&L);
                }
                if (createListFromInput(&L) == SUCCESS)
                {
                    printf("List created successfully! Current list: ");
                    TraverseList(L, printNode);
                    printf("NULL\n");
                }
                break;
                
           
            case 2://打印链表
                if (L == NULL) 
                {
                    printf("List is empty!\n");
                    break;
                }
                printf("Current list: ");
                TraverseList(L, printNode);
                printf("NULL\n");
                break;
                
            default:
                printf("Invalid choice, please try again!\n");
        }
    }
    
    return 0;
}